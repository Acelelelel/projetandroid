package com.example.projet

import android.content.Context
import android.graphics.Bitmap
import androidx.appcompat.content.res.AppCompatResources
import android.R
import android.graphics.Bitmap.createBitmap

import android.graphics.BitmapFactory




open class GameObject (
    private val ctx: Context,
    var id: Int,
    val rowCount: Int,
    val colCount: Int,
    var x: Int,
    var y: Int
    ) {
        private val image = AppCompatResources.getDrawable(ctx, id)
        val WIDTH: Int?
        private val HEIGHT: Int?
        val width: Int
        val height: Int

        fun createSubImageAt(row: Int, col: Int): Bitmap {
            val icon = BitmapFactory.decodeResource(ctx.resources, id)

            return createBitmap(icon, width*col, height*row, width, height)
        }

        init {
            WIDTH = if (image != null ){ image.intrinsicWidth } else { 0 }
            HEIGHT = if (image != null ){image.intrinsicHeight} else { 0 }
            width = WIDTH / colCount
            height = HEIGHT / rowCount
        }
    }
