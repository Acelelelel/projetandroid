package com.example.projet

import android.content.Context
import android.media.MediaPlayer

class SoundService {
    private lateinit var backgroundMusicPlayer: MediaPlayer
    private lateinit var ExplosionSound: MediaPlayer
    companion object{
        private lateinit var instance: SoundService
        private lateinit var ctx: Context
        fun get(ctx: Context): SoundService{
            if(!::instance.isInitialized){
                instance = sync
                this.ctx = ctx
            }
            return instance
        }

        @get:Synchronized
        private val sync: SoundService
            get() {
                if(!::instance.isInitialized) instance = SoundService()
                return instance
            }
    }

    fun playBackgroundMusic(){
        if(!::backgroundMusicPlayer.isInitialized){
            backgroundMusicPlayer = MediaPlayer.create(ctx, R.raw.backgroundsonore)
        }
        backgroundMusicPlayer.isLooping = true
        backgroundMusicPlayer.start()
    }



    fun playExplosionSound(){
        if(!::ExplosionSound.isInitialized){
            ExplosionSound = MediaPlayer.create(ctx, R.raw.explosion)
        }
        ExplosionSound.start()
    }

}