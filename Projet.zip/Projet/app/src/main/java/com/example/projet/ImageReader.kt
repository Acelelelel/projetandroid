package com.example.projet

import android.graphics.Bitmap
import android.graphics.Canvas


class ImageReader(
    private val gameSurface: GameSurface,
    image: Int,
    x: Int,
    y: Int,
    row: Int,
    col: Int,
    private val vertical: Boolean
) {
    private var rowIndex = if (vertical){-1}else {0}
    private var colIndex = if (vertical){0}else {-1}
    var isFinish = false
        private set
    private val gameObject = GameObject(gameSurface.context, image, row, col, x, y)

    fun update() {
        if (vertical) {
            rowIndex++
            if (rowIndex >= gameObject.rowCount) {
                rowIndex = 0
                colIndex++
                if (colIndex >= gameObject.colCount) {
                    isFinish = true
                }
            }
        } else {
            colIndex++
            if (colIndex >= gameObject.colCount) {
                colIndex = 0
                rowIndex++
                if (rowIndex >= gameObject.rowCount) {
                    isFinish = true
                }
            }
        }
    }

    fun draw(canvas: Canvas) {
        if (!isFinish) {
            val bitmap = gameObject.createSubImageAt(rowIndex, colIndex)
            canvas.drawBitmap(bitmap, gameObject.x.toFloat(), gameObject.y.toFloat(), null)
        }
    }

}