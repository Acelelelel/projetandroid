package com.example.projet

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_main)
        this.window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        this.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        // Attribution des axes par rapport aux images



        // Attribution des boutons à des variables

        val buttonplay = findViewById<ImageButton>(R.id.playbutton)
        val buttonsettings = findViewById<ImageButton>(R.id.settingsgame)
        val buttonexit = findViewById<ImageButton>(R.id.exitgame)



        // Ajout de la musique
        SoundService.get(this).playBackgroundMusic()

        // Bouton "Play"

        buttonplay.setOnClickListener {
            Toast.makeText(this, "Le combat se lance !", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, DeplacementActivity::class.java)
            startActivity(intent)
        }

        // Bouton "Exit"

        buttonexit.setOnClickListener {
            Toast.makeText(this, "Arrêt de l'application", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, finish()::class.java)
            startActivity(intent)
        }

        // Bouton "Settings"

        buttonsettings.setOnClickListener {

            Toast.makeText(this, "Affichage des options", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)

        }

        // Demarrage de la musique de fond du jeu (depuis un service)

//        val musicsound = findViewById<SeekBar>(R.id.volmusic)
//        musicsound?.setOnSeekBarChangeListener(object :
//            SeekBar.OnSeekBarChangeListener {
//            override fun onProgressChanged(seek: SeekBar, progress: Int, fromUser: Boolean) {
//                // write custom code for progress is changed
//            }
//            override fun onStartTrackingTouch(seek: SeekBar) {
//                // write custom code for progress is started
//            }
//
//            override fun onStopTrackingTouch(seek: SeekBar) {
//                // write custom code for progress is stopped
//                Toast.makeText(this@MainActivity,
//                    "Son : " + seek.progress + "%",
//                    Toast.LENGTH_SHORT).show()
//            }
//        })

    }

    }

