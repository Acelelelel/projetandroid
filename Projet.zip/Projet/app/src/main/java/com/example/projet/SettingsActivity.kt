package com.example.projet

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_settings)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        this.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        val buttonreglages = findViewById<Button>(R.id.reglages)
        val buttonstats = findViewById<Button>(R.id.stats)


        buttonstats.setOnClickListener{
            Toast.makeText(this, "Affichage des stats", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, SettingsStatsActivity::class.java)
            startActivity(intent)
        }


        buttonreglages.setOnClickListener{
            SoundService.get(this).playExplosionSound()
            Toast.makeText(this, "Affichage des réglages", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, SettingsReglagesActivity::class.java)
            startActivity(intent)
        }

    }

}