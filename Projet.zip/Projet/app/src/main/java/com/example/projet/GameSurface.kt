package com.example.projet

import android.app.Activity
import android.content.Context
import android.view.SurfaceHolder

import android.graphics.Canvas
import android.graphics.Rect

import android.view.MotionEvent

import android.media.SoundPool

import android.media.AudioManager

import android.media.AudioAttributes

import android.os.Build

import android.view.SurfaceView
import android.widget.ImageButton
import kotlin.random.Random


class GameSurface(context: Context?) : SurfaceView(context), SurfaceHolder.Callback {
    var limitY = 0
    private var gameThread: GameThread? = null
    private val chibiList: MutableList<ChibiCharacter> = ArrayList()
    private val imageReaderList: MutableList<ImageReader> = ArrayList<ImageReader>()
    private var soundIdExplosion = 0
    private var soundIdBackground = 0
    private var soundPoolLoaded = false
    private var soundPool: SoundPool? = null
    private fun initSoundPool() {
        // With Android API >= 21.
        if (Build.VERSION.SDK_INT >= 21) {
            val audioAttrib = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val builder = SoundPool.Builder()
            builder.setAudioAttributes(audioAttrib).setMaxStreams(MAX_STREAMS)
            soundPool = builder.build()
        } else {
            // SoundPool(int maxStreams, int streamType, int srcQuality)
            soundPool = SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0)
        }

        // When SoundPool load complete.
        soundPool!!.setOnLoadCompleteListener { soundPool, sampleId, status ->
            soundPoolLoaded = true

            // Playing background sound.
            playSoundBackground()
        }

//        // Load the sound background.mp3 into SoundPool
//        soundIdBackground = soundPool!!.load(this.context, R.raw.background, 1)

        // Load the sound explosion.wav into SoundPool
        soundIdExplosion = soundPool!!.load(this.context, R.raw.explosion, 1)
    }

    fun playSoundExplosion() {
        if (soundPoolLoaded) {
            val leftVolumn = 0.8f
            val rightVolumn = 0.8f
            // Play sound explosion.wav
            val streamId = soundPool!!.play(soundIdExplosion, leftVolumn, rightVolumn, 1, 0, 1f)
        }
    }

    fun playSoundBackground() {
        if (soundPoolLoaded) {
            val leftVolumn = 0.8f
            val rightVolumn = 0.8f
            // Play sound background.mp3
            val streamId = soundPool!!.play(soundIdBackground, leftVolumn, rightVolumn, 1, -1, 1f)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val x = event.x.toInt()
            val y = event.y.toInt()
            val iterator = chibiList.iterator()
            while (iterator.hasNext()) {
                val chibi = iterator.next()
                if (chibi.x < x && x < chibi.x + chibi.width && chibi.y < y && y < chibi.y + chibi.height) {
                    // Remove the current element from the iterator and the list.
                    iterator.remove()

                    // Creation de l'objet explosion.
//                    val bitmap = BitmapFactory.decodeResource(this.resources, R.drawable.explosion)
                    val explosion = ImageReader(this, R.drawable.explosion, chibi.x, chibi.y, 5, 5, false)
                    imageReaderList.add(explosion)
                }
            }
            return true
        }
        return false
    }
    fun move(x: Int, y: Int){
        chibiList[0].setMovingVector(x, y)
    }

    fun update() {
        chibiList[0].update()
        chibiList[1].updateIA(chibiList[0])
        for (action in imageReaderList) {
            action.update()
        }
        val iterator: MutableIterator<ImageReader> = imageReaderList.iterator()
        while (iterator.hasNext()) {
            val imageReader: ImageReader = iterator.next()
            if (imageReader.isFinish) {
                // If explosion finish, Remove the current element from the iterator & list.
                iterator.remove()
                continue
            }
        }
    }

    // Definition des collisions
    fun collision(): Boolean {

        var chibi0 = chibiList[0]
        var chibi1 = chibiList[1]

        // Creation des rectangles des chibis

        val hitboxchibi0: Rect = Rect(chibi0.x, chibi0.y, chibi0.x+chibi0.width, chibi0.y+chibi0.height)
        val hitboxchibi1: Rect = Rect(chibi1.x, chibi1.y, chibi1.x+chibi1.width, chibi1.y+chibi1.height)

        if (chibi0.x > chibi1.y &&
            chibi0.x < chibi1.x &&
            chibi0.y < (chibi1.x+chibi1.width) &&
            chibi0.y > (chibi1.y+chibi1.height) ) {
        }
        else if (   chibi0.y > chibi1.y &&
                    chibi0.y < chibi1.x &&
                    (chibi0.y+chibi0.height) < (chibi1.x+chibi1.width) &&
                    (chibi0.y+chibi0.height) > (chibi1.y+chibi1.height) ) {

        }
        else if (   (chibi0.y+chibi0.height) > chibi1.y &&
                    (chibi0.y+chibi0.height) < chibi1.x &&
                    (chibi0.x+chibi0.height) < (chibi1.x+chibi1.width) &&
                    (chibi0.x+chibi0.height) > (chibi1.y+chibi1.height) ) {

        }
        else if (   (chibi0.x+chibi0.height) > chibi1.y &&
                    (chibi0.x+chibi0.height) < chibi1.x &&
                    chibi0.x < (chibi1.x+chibi1.width) &&
                    chibi0.x > (chibi1.y+chibi1.height) ) {

        }
        return hitboxchibi0.intersect(hitboxchibi1)
    }

//    fun ghostmod(): Boolean {
//
//        val collisions = collision()
//        var chibi0 = chibiList[0]
//        var chibi1 = chibiList[1]
//
//        if(!collisions) {
//
//        }
//    }

    // Orientation des attaques

    fun attack() {

        if (!collision()){
            return
        }

        var chibi0 = chibiList[0]
        var chibi1 = chibiList[1]

        // Attaque vers le bas
        if (chibi0.lastMovingVectorX == 0 && chibi0.lastMovingVectorY > 0 ) {
            val attackdown =
                ImageReader(this, R.drawable.attaquebas, chibi0.x+(chibi0.currentMoveBitmap!!.width/4), chibi0.y+(chibi0.currentMoveBitmap!!.height), 3, 3, true)
            imageReaderList.add(attackdown)
        }

        // Attaque vers la droite
        else if (chibi0.lastMovingVectorX > 0 && chibi0.lastMovingVectorY == 0 ) {

            val attackright =
                ImageReader(this, R.drawable.attaquedroite, chibi0.x+(chibi0.currentMoveBitmap!!.width), chibi0.y+(chibi0.currentMoveBitmap!!.height/2), 3, 3, false)
            imageReaderList.add(attackright)
        }

        // Attaque vers la gauche
        else if (chibi0.lastMovingVectorX < 0 && chibi0.lastMovingVectorY == 0 ) {


            val attackleft =
                ImageReader(this, R.drawable.attaquegauche, chibi0.x-(chibi0.currentMoveBitmap!!.width/4), chibi0.y+(chibi0.currentMoveBitmap!!.height/2), 3, 3, false)
            imageReaderList.add(attackleft)
        }

        // Attaque vers le haut
        else if (chibi0.lastMovingVectorX == 0 && chibi0.lastMovingVectorY < 0 ) {

            val attackup =
                ImageReader(this, R.drawable.attaquehaut, chibi0.x+(chibi0.currentMoveBitmap!!.width/4), chibi0.y-(chibi0.currentMoveBitmap!!.height/2), 3, 3, true)
            imageReaderList.add(attackup)
        }
}
    fun defense() {
        var chibi0 = chibiList[0]
        var chibi1 = chibiList[1]


    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        for (chibi in chibiList) {
            chibi.draw(canvas)
        }
        for (explosion in imageReaderList) {
            explosion.draw(canvas)
        }
    }

    // Implements method of SurfaceHolder.Callback
    override fun surfaceCreated(holder: SurfaceHolder) {
        limitY = (context as Activity).findViewById<ImageButton>(R.id.up).top
        val chibi1 = ChibiCharacter(context, this,R.drawable.combatant1, 100, 50)
        val randX = rand(width/2, width)
        val randY = rand(0, limitY)
        val chibi2 = ChibiCharacter(context, this,R.drawable.combatant2, randX, randY)
        chibiList.add(chibi1)
        chibiList.add(chibi2)
        gameThread = GameThread(this, holder)
        gameThread!!.setRunning(true)
        gameThread!!.start()
    }
    fun rand(start: Int, end: Int): Int {
        require(start <= end) { "Illegal Argument" }
        val rand = Random(System.nanoTime())
        return (start..end).random(rand)
    }

    // Implements method of SurfaceHolder.Callback
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    // Implements method of SurfaceHolder.Callback
    override fun surfaceDestroyed(holder: SurfaceHolder) {
        var retry = true
        while (retry) {
            try {
                gameThread!!.setRunning(false)

                // Parent thread must wait until the end of GameThread.
                gameThread!!.join()
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
            retry = true
        }
    }

    companion object {
        private const val MAX_STREAMS = 100
    }

    init {

        // Make Game Surface focusable so it can handle events.
        this.isFocusable = true

        // Sét callback.
        this.holder.addCallback(this)
        initSoundPool()
    }
}