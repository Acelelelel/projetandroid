package com.example.projet

import android.R.attr
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import android.graphics.Bitmap
import android.R.attr.y

import android.R.attr.x
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout
import androidx.appcompat.widget.AppCompatImageButton
import androidx.recyclerview.widget.ItemTouchHelper.UP


class DeplacementActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_combat)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        this.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        val up = findViewById<ImageButton>(R.id.up)
        val down = findViewById<ImageButton>(R.id.bottom)
        val left = findViewById<ImageButton>(R.id.left)
        val right = findViewById<ImageButton>(R.id.right)
        val attackbutton = findViewById<ImageButton>(R.id.attack_button)

        val game = GameSurface(this)
        findViewById<RelativeLayout>(R.id.GameSurface).addView(game)

        // Bouton attaque

        attackbutton.setOnClickListener{

            game.attack()
        }

        // Bouton defense

//        attackbutton.setOnTouchListener{
//
//            game.defense
//    }
        // Deplacements avec les fleches

        up.setOnTouchListener { v, event ->

            if (event.action == MotionEvent.ACTION_DOWN) {
                game.move(0, -10)
            }
            else  if (event.action == MotionEvent.ACTION_UP) {
                game.move(0, 0)
            }

                return@setOnTouchListener true
        }
        down.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                game.move(0, 10)
            }
            else  if (event.action == MotionEvent.ACTION_UP) {
                game.move(0, 0)
            }

            return@setOnTouchListener true
        }
        left.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                game.move(-10, 0)
            }
            else  if (event.action == MotionEvent.ACTION_UP) {
                game.move(0, 0)
            }

            return@setOnTouchListener true
        }
        right.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                game.move(10, 0)
            }
            else  if (event.action == MotionEvent.ACTION_UP) {
                game.move(0, 0)
            }
            return@setOnTouchListener true
        }
    }


}