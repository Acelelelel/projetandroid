package com.example.projet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.example.projet.ChibiCharacter.Companion.ROW_BOTTOM_TO_TOP
import com.example.projet.ChibiCharacter.Companion.ROW_LEFT_TO_RIGHT
import com.example.projet.ChibiCharacter.Companion.ROW_RIGHT_TO_LEFT
import com.example.projet.ChibiCharacter.Companion.ROW_TOP_TO_BOTTOM

class Attaque(ctx : Context, gameSurface: GameSurface, id: Int, x: Int, y: Int) :
    GameObject(ctx, id, 3, 3, x, y) {

    private var rowUsing = ROW_LEFT_TO_RIGHT
    private var colUsing = 0
    private val AttackUp: Array<Bitmap?>
    private val AttackDown: Array<Bitmap?>
    private val AttackRight: Array<Bitmap?>
    private val AttackLeft: Array<Bitmap?>
    private var lastDrawNanoTime: Long = -1
    private val gameSurface: GameSurface

    init {
        this.gameSurface = gameSurface
        AttackUp = arrayOfNulls(colCount) // 3
        AttackDown = arrayOfNulls(colCount) // 3
        AttackRight = arrayOfNulls(colCount) // 3
        AttackLeft = arrayOfNulls(colCount) // 3
        for (col in 0 until this.colCount) {
            AttackUp[col] = this.createSubImageAt(ROW_TOP_TO_BOTTOM, col)
            AttackDown[col] = this.createSubImageAt(ROW_RIGHT_TO_LEFT, col)
            AttackRight[col] = this.createSubImageAt(ROW_LEFT_TO_RIGHT, col)
            AttackLeft[col] = this.createSubImageAt(ROW_BOTTOM_TO_TOP, col)
        }
    }
    val moveBitmaps: Array<Bitmap?>?
        get() = when (rowUsing) {
            ROW_BOTTOM_TO_TOP -> AttackUp
            ROW_LEFT_TO_RIGHT -> AttackRight
            ROW_RIGHT_TO_LEFT -> AttackLeft
            ROW_TOP_TO_BOTTOM -> AttackDown
            else -> null
        }
    val currentMoveBitmap: Bitmap?
        get() {
            val bitmaps = moveBitmaps
            return bitmaps!![colUsing]
        }

    fun draw(canvas: Canvas) {
        val bitmap = currentMoveBitmap
        canvas.drawBitmap(bitmap!!, x.toFloat(), y.toFloat(), null)
        // Last draw time.
        lastDrawNanoTime = System.nanoTime()
    }



}