package com.example.projet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas

class ChibiCharacter(ctx: Context, gameSurface: GameSurface, id: Int, x: Int, y: Int) :
    GameObject(ctx, id, 4, 3, x, y) {
    // Row index of Image are being used.
    private var rowUsing = ROW_LEFT_TO_RIGHT
    private var colUsing = 0
    private val leftToRights: Array<Bitmap?>
    private val rightToLefts: Array<Bitmap?>
    private val topToBottoms: Array<Bitmap?>
    private val bottomToTops: Array<Bitmap?>
    var lastMovingVectorX = 0
    var lastMovingVectorY = 0
    var movingVectorX = 0
    var movingVectorY = 0
    private var lastDrawNanoTime: Long = -1
    private val gameSurface: GameSurface
    val moveBitmaps: Array<Bitmap?>?
        get() = when (rowUsing) {
            ROW_BOTTOM_TO_TOP -> bottomToTops
            ROW_LEFT_TO_RIGHT -> leftToRights
            ROW_RIGHT_TO_LEFT -> rightToLefts
            ROW_TOP_TO_BOTTOM -> topToBottoms
            else -> null
        }
    val currentMoveBitmap: Bitmap?
        get() {
            val bitmaps = moveBitmaps
            return bitmaps!![colUsing]
        }

    fun updateIA(chibi: ChibiCharacter){
        chibi.x
    }

    // Actualisation du skin du chibi
    fun update() {

        if (movingVectorX == 0 && movingVectorY == 0 ){
            return
        }
        colUsing++
        if (colUsing >= this.colCount) {
            colUsing = 0
        }

        // temps actuel en nanosecondes
        val now = System.nanoTime()

        // Never once did draw.
        if (lastDrawNanoTime == -1L) {
            lastDrawNanoTime = now
        }
        // Changement des nanosecondes en milliseconde (1 nanoseconde = 1000000 millisecondes).
        val deltaTime = ((now - lastDrawNanoTime) / 1000000).toInt()

        // Distance des deplacements
        val distance = VELOCITY * deltaTime
        val movingVectorLength =
            Math.sqrt((movingVectorX * movingVectorX + movingVectorY * movingVectorY).toDouble())

        // Calcul de la nouvelle position des personnages.
        x = x + (distance * movingVectorX / movingVectorLength).toInt()
        y = y + (distance * movingVectorY / movingVectorLength).toInt()

        // Blocage des personnages au bord de l'ecran
        if (x < 0) {
            x = 0
        } else if (x > gameSurface.width - width) {
            x = gameSurface.width - width
        }
        if (y < 0) {
            y = 0
        } else if (y > gameSurface.limitY - height) {
            y = gameSurface.limitY - height
        }

        // Deplacement du personnage

        else if (movingVectorX > 0) {
            if (movingVectorY > 0 && Math.abs(movingVectorX) < Math.abs(movingVectorY)) {
                rowUsing = ROW_TOP_TO_BOTTOM
            } else if (movingVectorY < 0 && Math.abs(movingVectorX) < Math.abs(movingVectorY)) {
                rowUsing = ROW_BOTTOM_TO_TOP
            } else {
                rowUsing = ROW_LEFT_TO_RIGHT
            }
        } else {
            if (movingVectorY > 0 && Math.abs(movingVectorX) < Math.abs(movingVectorY)) {
                rowUsing = ROW_TOP_TO_BOTTOM
            } else if (movingVectorY < 0 && Math.abs(movingVectorX) < Math.abs(movingVectorY)) {
                rowUsing = ROW_BOTTOM_TO_TOP
            } else {
                rowUsing = ROW_RIGHT_TO_LEFT
            }
        }
    }

    fun draw(canvas: Canvas) {
        val bitmap = currentMoveBitmap
        canvas.drawBitmap(bitmap!!, x.toFloat(), y.toFloat(), null)
        // Last draw time.
        lastDrawNanoTime = System.nanoTime()
    }

    fun setMovingVector(movingVectorX: Int, movingVectorY: Int) {
        this.movingVectorX = movingVectorX
        this.movingVectorY = movingVectorY
        if (movingVectorX != 0 || movingVectorY != 0) {
            lastMovingVectorX = movingVectorX
            lastMovingVectorY = movingVectorY
        }
    }

    companion object {
        const val ROW_TOP_TO_BOTTOM = 0
        const val ROW_RIGHT_TO_LEFT = 1
        const val ROW_LEFT_TO_RIGHT = 2
        const val ROW_BOTTOM_TO_TOP = 3

        // Vitesse de déplacement des chibi
        var VELOCITY = 1.5f
    }

    init {
        this.gameSurface = gameSurface
        topToBottoms = arrayOfNulls(colCount) // 3
        rightToLefts = arrayOfNulls(colCount) // 3
        leftToRights = arrayOfNulls(colCount) // 3
        bottomToTops = arrayOfNulls(colCount) // 3
        for (col in 0 until this.colCount) {
            topToBottoms[col] = this.createSubImageAt(ROW_TOP_TO_BOTTOM, col)
            rightToLefts[col] = this.createSubImageAt(ROW_RIGHT_TO_LEFT, col)
            leftToRights[col] = this.createSubImageAt(ROW_LEFT_TO_RIGHT, col)
            bottomToTops[col] = this.createSubImageAt(ROW_BOTTOM_TO_TOP, col)
        }
    }
}