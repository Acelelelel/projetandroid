package com.example.projet

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder
import android.widget.ImageButton
import android.widget.SeekBar

const val ACTION_PLAY: String = "com.example.action.PLAY"

class Services: Service(), MediaPlayer.OnPreparedListener {

    private var mMediaPlayer: MediaPlayer? = null

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        val action = intent.action
        when(action) {
            ACTION_PLAY -> {
                mMediaPlayer = MediaPlayer.create(this, R.raw.backgroundsonore)
                mMediaPlayer!!.isLooping = true // Repetition de la musique une fois terminee
                mMediaPlayer!!.start() // forcing du lancement de la musique
            }
        }
        return startId

    }



    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    /** Called when MediaPlayer is ready */
    override fun onPrepared(mediaPlayer: MediaPlayer) {
        mediaPlayer.start()
    }
    fun volumeDown(){

    }
}